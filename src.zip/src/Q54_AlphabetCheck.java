import java.util.Scanner;

public class Q54_AlphabetCheck {

    public static void main(String[] args) {
        // Task->
        // Check if the character is among a-z or A-Z
        // girilen karakterin a-z or A-Z arasında olmasını kontrol eden code create ediniz

    }
}
