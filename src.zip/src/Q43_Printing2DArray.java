import java.util.Arrays;

public class Q43_Printing2DArray {

    // Task-> Print 2D String array using loops

    public static void main(String[] args) {


    }
}
