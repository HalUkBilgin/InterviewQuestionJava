import java.util.HashMap;

public class Q49_PrintMap {
    /*
        Hashmap ile 1 den 6 ya kadar sayilari sayi ve okunusu seklinde yazdirin
    */
    public static void main(String[] args) {

    }


}
