public class Q41_IFElse {
		/* Task->
        Write a method which prints out the numbers from 1 to 30 but for numbers which are a multiple of 3,
        print Rock instead of number and for numbers which are a multiple of 5, print Star instead of the number.
        For numbers which are a multiple by of both 3 and 5, print RockStar instead of the number.
        ORNEK:
            INPUT     : 1 2 3 4 ..... 30
            OUTPUT : 1 2 Rock 4 Star Rock 7 8 Rock Star 11 Rock 13 14 RockStar...
		 */

    public static void main(String[] args) {


    }
}
