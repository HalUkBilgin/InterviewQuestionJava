public class Q64_MountainArray {
    /*
     Bir Array'in Mountain Array olup olmadiğini kontrol eden bir kod yaziniz.
     Mountain Array: Element degerleri bir noktaya kadar surekli artip o noktadan sonra surekli azalan Array.
     arr[0] < arr[1] < arr[i] >arr[i+1] > arr[i+2] > arr[n-1]

    ----------------------------------------------------------------------------------------------------------------------*/
    public static void main(String[] args) {


    }//main sonu
}//Class sonu

