import java.util.Scanner;

public class Q60_SumWithoutLoop {
   /*
   Task-> girilen sayıya kadar olan pozitif tamsayıların toplamını loop kullanmadan print eden code create ediniz.
    */


    public static void main(String[] args) {



    }//main sonu


}
