public class Q44_PrintArray {
    //Task->
    // Create a method which takes String array as a parameter
    // and prints all the element

    public static void main(String[] args) {

    }
}
