import java.util.Arrays;
import java.util.Scanner;

public class Q58_AnagramControl {
    public static void main(String[] args) {
		/*
		    Anagram, bir kelimenin harflerinden baska bir kelime olusturmaya denir.
			Kullanıcıdan alınacak  iki kelimenin Anagram kontrolu yapan  Java method create ediniz
			isAnagram("listen", "Silent") ==> true
		 */


    }//main sonu
}//Class sonu
