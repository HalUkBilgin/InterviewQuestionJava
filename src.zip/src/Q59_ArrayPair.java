public class Q59_ArrayPair {
	
	
	 /* Task->
	   from a given array find all pairs whose sum is a  given number
	   Bir dizide istenen toplama eşit olan sayı ciftlerini print eden method create ediniz.
	   {4,6,5,-10,8,5,20}===>10
	    */
	
	public static void main(String[] args) {


		
	}//main sonu
}//Class sonu
