import java.util.Scanner;

public class Q62_PrintPrimeNumbers {

    public static void main(String[] args) {
        /* Task->
         * Print prime numbers which are less than the given number
         *  Girilen sayıya kadar asal sayıları print eden code create ediniz
         * input : 10
         * output : 2 3 5 7
         */


    }//main sonu
}//Class sonu
