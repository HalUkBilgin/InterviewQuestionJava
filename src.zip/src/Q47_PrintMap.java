import java.util.LinkedHashMap;
import java.util.Map;

public class Q47_PrintMap {
    //aşağıdaki çıktıyı elde ediniz
    // Kiraz 100
    // İncir 200
    // Enginar 150
    // Üzüm 145
    // Nar 250

    public static void main(String[] args) {

    }

}
