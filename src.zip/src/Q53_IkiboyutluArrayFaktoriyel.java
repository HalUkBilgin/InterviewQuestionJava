import java.util.Arrays;
import java.util.Scanner;


public class Q53_IkiboyutluArrayFaktoriyel {


    public static void main(String[] args) {
        // task-> girilen 3x3 iki boyutlu arrayin elemanlarının faktoriyelini print eden method create ediniz

    }
}
