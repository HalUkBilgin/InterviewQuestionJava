import java.util.LinkedHashMap;
import java.util.Map;

public class Q48_PrintMap {
    /*
    10, Java
    20, PHP
    2,  Python
    57, C++
    89, C#
    40, Javascript
    Map kullanarak yazınız
     */
    public static void main(String[] args) {

    }
}



