public class Q01_ReverseString {
        /* Task->
	     Stringi tersten print için
		1.Yol: StringBuilder () kullanarak
		2.Yol: String Classini kullanarak
		3.Yol: Bir method create ediniz
    */

    public static void main(String[] args) {


    }//main sonu
}//class sonu
