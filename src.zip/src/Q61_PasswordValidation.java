public class Q61_PasswordValidation {
    /*
     * 1. Password MUST be at least have 6 characters and should not contain space
     * 2. PassWord should at least contain one upper case letter
     * 3. PassWord should at least contain one lower case letter
     * 4. Password should at least contain one special characters
     * 5. Password should at least contain a digit
     */
    public static void main(String[] args) {



    }//main sonu
}//Class sonu
